const express = require('express');
const router = express.Router();
const cart = require('../models/CartModel')
const cartSanitizer = require('./helpers/cart-sanitizer');

// Ulančavanje funkcija međuopreme
router.get('/', cartSanitizer, function (req, res, next) {
    //####################### ZADATAK #######################
    // prikaz košarice uz pomoć cart.ejs

    if (req.session.cart == undefined) {
        req.session.cart = cart.createCart();
    }

    res.render('cart', { 
        err: undefined,
        cart: req.session.cart, 
        user: req.session.user, 
        title: 'Cart',
        linkActive: 'cart' 
    });
    //#######################################################
});


router.get('/add/:id', function (req, res, next) {
    //####################### ZADATAK #######################
    //dodavanje jednog artikla u košaricu

    if (req.session.cart == undefined) {
        req.session.cart = cart.createCart();
    }


    (async() => {
        let id = parseInt(req.params.id);
    

        await cart.addItemToCart(req.session.cart, id, 1);

        res.redirect('/');
    })();

    

    // req.session.history.setItem("cart", cart);
    //#######################################################


});

router.get('/remove/:id', function (req, res, next) {
    //####################### ZADATAK #######################
    //brisanje jednog artikla iz košarice

    (async() => {
        let id = parseInt(req.params.id);
    

        await cart.removeItemFromCart(req.session.cart, id, 1);

        res.redirect('/');
    })();
    //#######################################################


});

module.exports = router;