const express = require('express');
const router = express.Router();
const User = require('../models/UserModel')
const Order = require('../models/OrderModel')
const cart = require('../models/CartModel')


router.get('/', function (req, res, next) {
    //####################### ZADATAK #######################
    //vrati login stranicu

    res.render('login', { 
        err: undefined, 
        user: req.session.user, 
        title: 'Login',
        linkActive: 'login' 
    });
    //#######################################################

});

router.post('/', function (req, res, next) {
    //####################### ZADATAK #######################
    //postupak prijave korisnika
    (async()=> {

      let user = await User.fetchByUsername(req.body.user);
      // let order = await Order.fetchByUser(user)[0];
      // console.log(order);

      // if (order !== undefined) {
      //   let oldCart = order.cart;

      //   for(let item of Object.values(cart.items)) {
      //     await cart.addItemToCart(req.session.cart, item.id, item.quantity);
      // }
      // }
      

      if (user.id == undefined) {
        res.render('login', { 
          err: 'Username incorrect', 
          user: req.session.user, 
          title: 'Login',
          linkActive: 'login' 
        });
        return;
      }

      if (user.password != req.body.password) {
        res.render('login', { 
          err: 'Password incorrect', 
          user: req.session.user, 
          title: 'Login',
          linkActive: 'login' 
        });
        return;
      }

      req.session.user = user;
      res.redirect('/');


      

    })();

    //#######################################################

});


module.exports = router;