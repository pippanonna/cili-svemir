const express = require('express');
const router = express.Router();

router.get('/', function (req, res, next) {
    //####################### ZADATAK #######################
    // - obrisati sadržaj košarice
    // - odjaviti registriranog korisnika iz sustava
    // - napraviti redirect na osnovnu stranicu

    req.session.cart = undefined;

    req.session.user = undefined;

    req.session.history = undefined;
  
    //destroy session object
    req.session.destroy((err) => {
        
        if(err) {
        //report possible error
        console.log(err);
        }
        else {
        //redirect to the main page
        res.redirect('/');
        }
    });


    //#######################################################

});

module.exports = router;