// potrebno napisati
const express = require('express');
const router = express.Router();
const db = require('../db');

router.get('/:id', async function (req, res, next) {
    let id = parseInt(req.params.id);
    
    const sqlItem = `SELECT id, name, price, categoryid, imageurl, colors FROM inventory WHERE id = ${id};`;
    try {
        const item = ((await db.query(sqlItem, [])).rows)[0];
        const sqlItemCategory = `SELECT * FROM categories WHERE id = ${item.categoryid};`;
        const category = ((await db.query(sqlItemCategory, [])).rows)[0];
        
        res.render('item', {
            title: item.name,
            item: item,
            category: category,
            linkActive: 'order'
        });
    } catch (err) {
        console.log(err);
    }
    
});


module.exports = router;