// potrebno napisati
const express = require('express');
const router = express.Router();
const db = require('../db');

router.get('/', async function (req, res, next) {
    const sqlForCategories = `SELECT id, name, description, seasonal FROM categories ORDER BY id;`;
    const sqlForInventory = `SELECT id, name, price, categoryid, imageurl, colors FROM inventory ORDER BY categoryid, id;`;
    try {
        const categories = (await db.query(sqlForCategories, [])).rows;
        const inventory = (await db.query(sqlForInventory, [])).rows;
        let catItemMap = {};
        for (let category of categories) {
            catItemMap[category.id] = [];
        }
        for (let item of inventory) {
            catItemMap[item.categoryid].push(item);
        }
        res.render('order', {
            title: 'Order',
            categories: categories,
            items: catItemMap,
            linkActive: 'order'
        });
    } catch (err) {
        console.log(err);
    }
});

module.exports = router;